debugger;

import $GM from './es6/index.js';
//------------------

import historyModule from './es6/index.js';
const { bbHistory, historyExtend: hisExtend } = historyModule($GM);

export { bbHistory };
export var historyExtend = function (bb) {
  $GM.set('bb', bb);
  hisExtend(bb);
}

export default historyModule;
