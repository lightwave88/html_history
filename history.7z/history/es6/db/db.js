'use strict';

let $GM;

import $device from './device.js';
// 裝置列表
const { memory, session } = $device;

// 處理 stateData
class HistoryDB {

  $history;
  // 裝置
  $devices = new Map();
  $deviceName;
  $defaultDevice = 'memory';
  //----------------------------------------------------------------------------
  constructor(history) {
    // 預設是記錄在記憶體
    this.$history = history;
    this.setDevice(this.$defaultDevice);
  }
  //----------------------------------------------------------------------------
  set(key, value) {
    checkKey(key);

    const device = getCurrentDevice(this);
    return device.set(key, value);
  }
  //----------------------------------------------------------------------------
  get(key) {
    checkKey(key);
    const device = getCurrentDevice(this);
    return device.get(key);
  }
  //----------------------------------------------------------------------------
  has(key) {
    checkKey(key);
    const device = getCurrentDevice(this);
    return device.has(key);
  }
  //----------------------------------------------------------------------------
  delete(key) {
    checkKey(key);
    const device = getCurrentDevice(this);
    return device.delete(key);
  }
  //----------------------------------------------------------------------------
  clear() {
    const device = getCurrentDevice(this);
    return device.clear();
  }
  //----------------------------------------------------------------------------
  keys() {
    const device = getCurrentDevice(this);
    return Array.from(device.keys());
  }
  //----------------------------------------------------------------------------
  values() {
    const device = getCurrentDevice(this);
    return Array.from(device.values());
  }
  //----------------------------------------------------------------------------
  // 往下一個時間的 data
  nextHis() {
    const device = getCurrentDevice(this);
    return device.nextHis();
  }

  // 往上一個時間的 data
  prevHis() {
    const device = getCurrentDevice(this);
    return device.prevHis();
  }
  //----------------------------------------------------------------------------
  toJSON() {
    const device = this.$devices.get(this.$deviceName);
    return device.toJSON();
  }
  //----------------------------------------------------------------------------
  setDevice(device) {
    debugger;
    if (!(device in $device)) {
      throw new Error('沒有提供這設備');
    }

    if (device == this.$deviceName) {
      // 與現在使用的設備相同
      return;
    }
    //------------------
    let prevDeviceName = null;

    if (this.$deviceName != null) {
      // 記錄之前的裝置名稱
      prevDeviceName = this.$deviceName;
    }

    this.$deviceName = device;
    //------------------
    let newDevice;
    if (!this.$devices.has(device)) {
      // 初始化
      const DeviceClass = $device[device];
      debugger;
      newDevice = new DeviceClass(this.$history)
      this.$devices.set(device, newDevice);
    }
    //------------------
    if (prevDeviceName != null) {
      // 拷貝資料
      let oldDevice = this.$devices.get(prevDeviceName);
      oldDevice.cloneDevice(oldDevice)
    }
  }
  //----------------------------------------------------------------------------
  setByTime(timeId, data = {}) {
    const device = getCurrentDevice(this);
    device.setByTime(timeId, data);
  }

  getByTime(timeId) {
    const device = getCurrentDevice(this);
    return device.getByTime(timeId);
  }

  deleteByTime(timeID) {
    const device = getCurrentDevice(this);
    device.deleteByTime(timeID);
  }

  hasByTime(timeId) {
    const device = getCurrentDevice(this);
    return device.hasByTime(timeId);
  }
}
//------------------------------------------------------------------------------
function checkKey(key) {
  if (typeof key != 'string') {
    throw new TypeError(`key(${key}) must be string`);
  }
}

function getCurrentDevice(obj) {
  const device = obj.$devices.get(obj.$deviceName);
  return device;
}

export default function (gm) {
  $GM = gm;
  return HistoryDB;
}
