'use strict';

class DBInterface {
  $type = '';
  // 據連續性的 data
  // $continuousKeys = new Set();
  $history;

  // 是否有指定靜態的 hisID
  // $static_hisID;
  //--------------------------------------
  constructor(his) {
    debugger;
    this.$history = his;
    // if (hisID != null) {
    //   this.$static_hisID = hisID;
    // }
  }
  //--------------------------------------
  // 根據當前的 history
  set(key, value) { }
  //--------------------------------------
  // 根據當前的 history
  get(key) { }
  //--------------------------------------
  // 根據當前的 history
  has(key) { }
  //--------------------------------------
  // 根據當前的 history
  delete(key) { }
  //--------------------------------------
  // 根據當前的 history
  keys() { }
  //--------------------------------------
  // 根據當前的 history
  values() { }
  //--------------------------------------
  // 根據當前的 history
  clear() { }
  //--------------------------------------
  // 根據當前的 history
  size() { }
  //--------------------------------------
  // 往下一個時間的 data
  nextHis() { }

  // 往上一個時間的 data
  prevHis() { }
  //--------------------------------------
  // 互相轉移資料
  cloneDevice(device) {
    let data = device.toJSON();
    for (let k in data) {
      this.set(k, data);
    }
  }
  //--------------------------------------
  toJSON() { }
  //--------------------------------------
  setByTime(timeId, data = {}) { }

  getByTime(timeId) { }

  deleteByTime(timeID) { }

  hasByTime(timeId) { }

  //--------------------------------------
  _getHisID() {
    // debugger;
    return this.$history.$current_stateID;
  }
}


////////////////////////////////////////////////////////////////////////////////
const Memory = (() => {

  // 資料建構在記憶體
  // 會隨着頁面的不同消散
  class Memory extends DBInterface {

    $type = 'memory';

    // 資料庫
    $db = new Map();
    //--------------------------------------
    constructor(his) {
      super(his);
    }
    //--------------------------------------
    set(key, value) {
      // debugger;

      let data = this._hasCurrentHisData(true);
      data[key] = value;
    }
    //--------------------------------------
    get(key) {
      // debugger;

      let data = this._hasCurrentHisData();

      if (data == null) {
        return null;
      }
      return (key in data) ? data[key] : null;
    }
    //--------------------------------------
    has(key) {
      // debugger;

      let data = this._hasCurrentHisData();

      if (data == null) {
        return false;
      }
      return (key in data);
    }
    //--------------------------------------
    delete(key) {
      // debugger;

      let data = this._hasCurrentHisData();

      if (data == null || !(key in data)) {
        return false;
      }
      delete (data[key]);
      return true;
    }
    //--------------------------------------
    keys() {
      // debugger;

      let data = this._hasCurrentHisData();

      if (data == null) {
        return [];
      }
      return Object.keys(data);
    }
    //--------------------------------------
    values() {
      // debugger;

      let data = this._hasCurrentHisData();

      if (data == null) {
        return [];
      }
      return Object.values(data);
    }
    //--------------------------------------
    clear() {
      // debugger;

      let hisId = this._getHisID();
      this.deleteByTime(hisId);
    }
    //--------------------------------------
    size() {
      // debugger;
      let data = this._hasCurrentHisData();

      if (data == null) {
        return 0;
      }

      return Array.keys(data).length;
    }
    //--------------------------------------
    // 取得下一個 his 的資料
    nextHis() {
      debugger;

      const historyData = this.$history.$historyData;
      const $this = this;

      let keyList = Array.from(historyData.keys());
      keyList.sort();

      let hisID = this._getHisID();
      let index = keyList.indexOf(hisID);

      keyList = keyList.slice(index + 1);

      // 迭代
      const it = {
        next() {
          debugger;
          let id = keyList.shift();

          if (id == null) {
            return { done: true };
          }

          let data = $this.getByTime(id);

          return {
            value: [id, data],
            done: false,
          };
        },
        [Symbol.iterator]() { return this },
      };

      return it;
    }
    //--------------------------------------
    // 取得上一個 his 的資料
    prevHis() {
      debugger;

      const historyData = this.$history.$historyData;
      const $this = this;

      let keyList = Array.from(historyData.keys());
      keyList.sort();

      let hisID = this._getHisID();
      let index = keyList.indexOf(hisID);

      keyList = keyList.slice(0, index);

      const it = {
        next() {
          debugger;
          let id = keyList.pop();
          if (id == null) {
            return { done: true };
          }

          let data = $this.getByTime(id);
          return {
            value: [id, data],
            done: false,
          };

        },
        [Symbol.iterator]() { return this },
      };

      return it;
    }
    //--------------------------------------
    // 返回 {}
    toJSON() {
      let data = {};
      this.$db.forEach((v, k) => {
        data[k] = v;
      });
      return data;
    }
    //--------------------------------------
    setByTime(timeId, data = {}) {
      this.$db.set(timeId, data);
    }

    getByTime(timeId) {
      if (!this.$db.has(timeId)) {
        return null;
      }
      return this.$db.get(timeId);
    }

    deleteByTime(timeId) {
      this.$db.delete(timeId);
    }

    hasByTime(timeId) {
      return this.$db.has(timeId);
    }
    //--------------------------------------
    _hasCurrentHisData(init = false) {
      // debugger;

      let hisID = this._getHisID();

      if (!this.$db.has(hisID) && init) {
        // 初始化
        //資料庫格式是 {}
        this.$db.set(hisID, {});
      }
      //-------------
      let data = this.$db.has(hisID) ? this.$db.get(hisID) : null;
      return data;
    }
  }
  //------------------------------------------------

  return Memory;
})();

////////////////////////////////////////////////////////////////////////////////

// 資料建構在 seesionStorage
// 資料會保存到 browser 關閉
class Session extends DBInterface {
  $type = 'session';

  $dbName = '$$$historyData';
  $db;


  constructor() {
    if (sessionStorage.getItem(this.$dbName) == null) {
      sessionStorage.setItem(this.$dbName, {});
    }
    this.$db = sessionStorage.getItem(this.$dbName);
  }
  //--------------------------------------
  set(key, value) {

  }
  //--------------------------------------
  get(key) {

  }
  //--------------------------------------
  has(key) {

  }
  //--------------------------------------
  delete(key) {

  }
  //--------------------------------------
  keys() {

  }
  //--------------------------------------
  values() {

  }
  //--------------------------------------
  clear() {

  }
  //--------------------------------------
  cloneDevice(data = {}) {
    super.cloneDevice(device);
  }
}



////////////////////////////////////////////////////////////////////////////////
export default {
  memory: Memory,
  session: Session,
};
